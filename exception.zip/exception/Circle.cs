﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab5exception
{
    internal class Circle
    {
        public double Radius { get; set; }
        /*private double _radius;
        public double Radius
        {
            get
            {
                return _radius;
                
            }
            set
            {
                if (value < 0 || double.IsInfinity(value))
                    throw new InvalidRadiusException("Radius can not be negative");
                _radius = value;
            }
        }*/

        public Circle(double radius) 
        {
            //default constructor cuz empty no parameter 
            if (radius < 0 || double.IsInfinity(radius))
                throw new InvalidRadiusException("Radius can not be negative");
            Radius = radius;
        }

        public double Area()
        {
            //return Math.PI * (Radius * Radius);
            return Math.PI * Math.Pow(Radius, 2);
        }

        public override string ToString()
        {
            return "Area: " + this.Area();
        }
    }
}
