﻿using lab5exception;
using System.Diagnostics;

namespace lab5exception
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Circle circle1 = new Circle(10);
            try
            {
                Circle circle2 = new Circle(-10);
            }
            catch (Exception ex)
            //catch (InvalidCastException ex)
            {
                //debug to save the error message 
                Debug.WriteLine(ex.ToString());
            }

            //Circle circle2 = new Circle(-10);
            Circle circle3 = new Circle(0);

            Console.WriteLine(circle1);
            //Console.WriteLine(circle2);
            Console.WriteLine(circle3);
        }
    }

}